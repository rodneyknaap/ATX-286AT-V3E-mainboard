/* Quartus II 64-Bit Version 13.0.1 Build 232 06/12/2013 Service Pack 1 SJ Web Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EPM7256SQ208) Path("O:/80286 Mainboard/@286 AT PC ATX mainboard/000_REV_3E/CPLD_CHIPSET/U5_EMS_CONTROLLER@EMS_DISABLES_XMS_5678/output_files/") File("U5_EMS_CONTROLLER.pof") MfrSpec(OpMask(3));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
