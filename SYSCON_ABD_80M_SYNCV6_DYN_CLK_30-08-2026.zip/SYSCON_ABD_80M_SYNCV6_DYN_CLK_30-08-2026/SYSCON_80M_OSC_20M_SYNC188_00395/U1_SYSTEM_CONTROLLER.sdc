# ====================================================================
# CONFIGURATIE VOOR QUARTUS TIMEQUEST - REV3E SYSTEM CONTROLLER CPLD
# ====================================================================

# --------------------------------------------------------------------
# 1. HARDWARE MASTER KLOKKEN (Fysieke ingangspinnen)
# FCLOCK komt binnen via een oscillator van 80 MHz (periode = 12.5 ns)
# --------------------------------------------------------------------
create_clock -period 12.500 -name master_fclock [get_ports {FCLOCK}]


# --------------------------------------------------------------------
# 2. VASTE GEGENEREERDE KLOKKEN (Vaste delers uit de 'freqdiv' instantie)
# We definiëren de exacte registers die de frequentie omlaag brengen.
# --------------------------------------------------------------------

# DIV_FCLOCK (40 MHz): Gedeeld door 2 vanuit FCLOCK
create_generated_clock -name clk_div_fclock \
    -source [get_ports {FCLOCK}] \
    -divide_by 2 \
    [get_registers {inst14|21}]

# 286_SL_CLK (20 MHz): Gedeeld door 4 vanuit FCLOCK
create_generated_clock -name clk_286_sl \
    -source [get_ports {FCLOCK}] \
    -divide_by 4 \
    [get_registers {inst14|22}]

# 287_CLK (10 MHz): Gedeeld door 8 vanuit FCLOCK
create_generated_clock -name clk_287 \
    -source [get_ports {FCLOCK}] \
    -divide_by 8 \
    [get_registers {inst14|23}]

# DMA_CLK (5 MHz): Gedeeld door 16 vanuit FCLOCK
# create_generated_clock -name clk_dma \
#    -source [get_ports {FCLOCK}] \
#    -divide_by 24 \
#    [get_registers {inst186}]


# ====================================================================
# 3A & 3B. VIRTUELE DYNAMISCHE KLOKKEN & HOE KOPPELEN AAN HARDWARE
# We definiëren de klokken en wijzen ze direct toe aan de registers.
# Dit voorkomt de Quartus-crash én lost de 'Node without clock assignment' op!
# ====================================================================

# 1. Definieer de klokken voor FCLOCK_MUX (Symbool 1, inst123)
create_clock -period 12.500 -name clk_fclock_mux_fast [get_registers {inst123|clk_select_reg}]
create_clock -period 25.000 -name clk_fclock_mux_slow [get_registers {inst123|clk_select_reg}] -add
set_clock_groups -logically_exclusive -group {clk_fclock_mux_fast} -group {clk_fclock_mux_slow}

# 2. Definieer de klokken voor 286_CLK (Symbool 2, bijvoorbeeld inst124)
# Vervang 'inst124' door de echte instantienaam van uw tweede mux-symbool.
create_clock -period 25.000 -name clk_cpu_bus_fast [get_registers {inst124|clk_select_reg}]
create_clock -period 50.000 -name clk_cpu_bus_slow [get_registers {inst124|clk_select_reg}] -add
set_clock_groups -logically_exclusive -group {clk_cpu_bus_fast} -group {clk_cpu_bus_slow}


# ====================================================================
# 5. AFGELEIDE KLOKKEN (Gekoppeld aan de fysieke deler-registers)
# Hiermee lossen we de Warning (332060) op voor inst70 en opvolgers!
# ====================================================================

# SYS_CLK (Gegenereerd door TFF 21 in de 'inst70' freqdiv instantie)
create_clock -period 50.000  -name clk_sys_fast [get_registers {inst70|21}]
create_clock -period 100.000 -name clk_sys_slow [get_registers {inst70|21}] -add
set_clock_groups -logically_exclusive -group {clk_sys_fast} -group {clk_sys_slow}

# SD_CLK (Gegenereerd door TFF 22 in de 'inst70' freqdiv instantie)
create_clock -period 100.000 -name clk_sd_fast  [get_registers {inst326|21}]
create_clock -period 200.000 -name clk_sd_slow  [get_registers {inst326|21}] -add
set_clock_groups -logically_exclusive -group {clk_sd_fast} -group {clk_sd_slow}

# CLK_SHTD (Gegenereerd door TFF 23 of 24 in de 'inst70' freqdiv instantie)
# Controleer of CLK_SHTD uit register 23 of 24 komt, pas het nummer hieronder aan indien nodig:
create_clock -period 200.000 -name clk_shtd_fast [get_registers {inst326|22}]
create_clock -period 400.000 -name clk_shtd_slow [get_registers {inst326|22}] -add
set_clock_groups -logically_exclusive -group {clk_shtd_fast} -group {clk_shtd_slow}

# ====================================================================
# 6. ALE SIGNALEERING (Definitieve, stabiele CPLD-oplossing voor inst233)
# We definiëren ALE direct op het register om 'No paths exist' te omzeilen.
# ====================================================================

# Modus A: ALE timing tijdens de snelle 20MHz CPU-modus (volgt het SYS_CLK ritme van 50ns)
create_clock -period 50.000  -name clk_ale_fast [get_registers {inst233}]

# Modus B: ALE timing tijdens de trage 10MHz CPU-modus (volgt het SYS_CLK ritme van 100ns)
create_clock -period 100.000 -name clk_ale_slow [get_registers {inst233}] -add

# Deze twee modi sluiten elkaar fysiek en logisch uit
set_clock_groups -logically_exclusive -group {clk_ale_fast} -group {clk_ale_slow}





