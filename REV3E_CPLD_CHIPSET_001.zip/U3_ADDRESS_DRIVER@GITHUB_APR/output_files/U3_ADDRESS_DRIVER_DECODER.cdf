/* Quartus II 64-Bit Version 13.0.1 Build 232 06/12/2013 Service Pack 1 SJ Web Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EPM7256SQ208) Path("O:/80286 Mainboard/@286 AT PC ATX mainboard/000_REV_3_D/CPLD_CHIPSET/U3_ADDRESS_DRIVER_REGISTERS_DMA_FIXED_UT@/output_files/") File("U3_ADDRESS_DRIVER_DECODER.pof") MfrSpec(OpMask(3));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
