module glitchless_clk_mux (
    input wire fclock,       // De snelle master-klok (bijv. 44.8 MHz of 50 MHz input)
    input wire clk_286_sl,   // De trage VGA-interleave klok (286_SL_CLK)
    input wire slowcycle,    // Het stuursignaal: 1 = traag, 0 = snel
    input wire reset_n,      // Systeem-reset (active-low)
    output wire clk_286_out  // De uiteindelijke, ijskoude klok naar je 286 CPU!
);

    reg clk_select_reg;

    // We samplen het slowcycle-signaal veilig op de vallende flank van FCLOCK.
    // Dit zorgt ervoor dat we NOOIT halverwege een klokpuls omschakelen.
    always @(negedge fclock or negedge reset_n) begin
        if (!reset_n)
            clk_select_reg <= 1'b0; // Start altijd in Fast-mode
        else
            clk_select_reg <= slowcycle;
    end

    // De glitch-vrije hardware multiplexer
    assign clk_286_out = clk_select_reg ? clk_286_sl : fclock;

endmodule